# Infidelity Coders
## DeFi Hackathon

![](./lol.png)

# Team Members
|Name|Post|
|-|-|
|Vivan Jaiswal|UI/UX|
|Lokesh Agarwal|Frontend|
|Gautam Vhavle|Designing|
|Aayush Kumar|Co-Designing|
